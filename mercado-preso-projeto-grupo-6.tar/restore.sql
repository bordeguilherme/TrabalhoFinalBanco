--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mercado_preso;
--
-- Name: mercado_preso; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mercado_preso WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE mercado_preso OWNER TO postgres;

\connect mercado_preso

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    cat_cd_id integer NOT NULL,
    cat_tx_nome character varying(20),
    cat_tx_descricao character varying(120)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cat_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cat_cd_id_seq OWNER TO postgres;

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cat_cd_id_seq OWNED BY public.categoria.cat_cd_id;


--
-- Name: estoque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estoque (
    estq_cd_id integer NOT NULL,
    estq_int_total integer,
    fk_prodt_cd_id integer
);


ALTER TABLE public.estoque OWNER TO postgres;

--
-- Name: estoque_estq_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estoque_estq_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estoque_estq_cd_id_seq OWNER TO postgres;

--
-- Name: estoque_estq_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estoque_estq_cd_id_seq OWNED BY public.estoque.estq_cd_id;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    ped_cd_id integer NOT NULL,
    ped_dt_data timestamp without time zone,
    fk_usu_cd_id integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pedido_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_produto (
    fk_ped_cd_id integer,
    fk_prodt_cd_id integer
);


ALTER TABLE public.pedido_produto OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    prodt_cd_id integer NOT NULL,
    prodt_tx_nome character varying(50),
    prodt_tx_descricao character varying(120),
    prodt_dt_fab date,
    prodt_int_estoque integer,
    prodt_nm_valor numeric,
    fk_cat_cd_id integer,
    fk_usu_cd_int integer
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usu_cd_id integer NOT NULL,
    usu_tx_nome character varying(50),
    usu_tx_end character varying(40),
    usu_txt_telefone character varying(11),
    usu_int_numero_usu integer,
    usu_tx_email character varying(30),
    usu_tx_cpf character varying(11),
    usu_dt_data_nasc date
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: nota_fiscal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.nota_fiscal AS
 SELECT usc.usu_cd_id AS "codigo do comprador",
    pr.prodt_tx_nome AS "nome do produto",
    pr.prodt_nm_valor AS valor,
    usc.usu_tx_nome AS comprador,
    usv.usu_tx_nome AS vendedor,
    pe.ped_dt_data AS data
   FROM ((((public.pedido pe
     JOIN public.pedido_produto pp ON ((pe.ped_cd_id = pp.fk_ped_cd_id)))
     JOIN public.produto pr ON ((pr.prodt_cd_id = pp.fk_prodt_cd_id)))
     JOIN public.usuario usv ON ((usv.usu_cd_id = pr.fk_usu_cd_int)))
     JOIN public.usuario usc ON ((usc.usu_cd_id = pe.fk_usu_cd_id)));


ALTER TABLE public.nota_fiscal OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_ped_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_ped_cd_id_seq OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_ped_cd_id_seq OWNED BY public.pedido.ped_cd_id;


--
-- Name: produto_prodt_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_prodt_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_prodt_cd_id_seq OWNER TO postgres;

--
-- Name: produto_prodt_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_prodt_cd_id_seq OWNED BY public.produto.prodt_cd_id;


--
-- Name: usuario_usu_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_usu_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_usu_cd_id_seq OWNER TO postgres;

--
-- Name: usuario_usu_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_usu_cd_id_seq OWNED BY public.usuario.usu_cd_id;


--
-- Name: categoria cat_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cat_cd_id SET DEFAULT nextval('public.categoria_cat_cd_id_seq'::regclass);


--
-- Name: estoque estq_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque ALTER COLUMN estq_cd_id SET DEFAULT nextval('public.estoque_estq_cd_id_seq'::regclass);


--
-- Name: pedido ped_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN ped_cd_id SET DEFAULT nextval('public.pedido_ped_cd_id_seq'::regclass);


--
-- Name: produto prodt_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN prodt_cd_id SET DEFAULT nextval('public.produto_prodt_cd_id_seq'::regclass);


--
-- Name: usuario usu_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN usu_cd_id SET DEFAULT nextval('public.usuario_usu_cd_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3370.dat

--
-- Data for Name: estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3376.dat

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3374.dat

--
-- Data for Name: pedido_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3377.dat

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3372.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3368.dat

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cat_cd_id_seq', 3, true);


--
-- Name: estoque_estq_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estoque_estq_cd_id_seq', 15, true);


--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_ped_cd_id_seq', 3, true);


--
-- Name: produto_prodt_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_prodt_cd_id_seq', 15, true);


--
-- Name: usuario_usu_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_usu_cd_id_seq', 5, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cat_cd_id);


--
-- Name: estoque estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque
    ADD CONSTRAINT estoque_pkey PRIMARY KEY (estq_cd_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (ped_cd_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (prodt_cd_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usu_cd_id);


--
-- Name: idx_produto_nome; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_produto_nome ON public.produto USING btree (prodt_tx_nome);


--
-- Name: idx_produtos; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_produtos ON public.pedido_produto USING btree (fk_prodt_cd_id);


--
-- Name: estoque estoque_fk_prodt_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque
    ADD CONSTRAINT estoque_fk_prodt_cd_id_fkey FOREIGN KEY (fk_prodt_cd_id) REFERENCES public.produto(prodt_cd_id);


--
-- Name: pedido pedido_fk_usu_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_fk_usu_cd_id_fkey FOREIGN KEY (fk_usu_cd_id) REFERENCES public.usuario(usu_cd_id);


--
-- Name: pedido_produto pedido_produto_fk_ped_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_fk_ped_cd_id_fkey FOREIGN KEY (fk_ped_cd_id) REFERENCES public.pedido(ped_cd_id);


--
-- Name: pedido_produto pedido_produto_fk_prodt_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_fk_prodt_cd_id_fkey FOREIGN KEY (fk_prodt_cd_id) REFERENCES public.produto(prodt_cd_id);


--
-- Name: produto produto_fk_cat_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fk_cat_cd_id_fkey FOREIGN KEY (fk_cat_cd_id) REFERENCES public.categoria(cat_cd_id);


--
-- Name: produto produto_fk_usu_cd_int_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fk_usu_cd_int_fkey FOREIGN KEY (fk_usu_cd_int) REFERENCES public.usuario(usu_cd_id);


--
-- Name: TABLE categoria; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.categoria TO vendedor;


--
-- Name: SEQUENCE categoria_cat_cd_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.categoria_cat_cd_id_seq TO vendedor;
GRANT ALL ON SEQUENCE public.categoria_cat_cd_id_seq TO cliente;


--
-- Name: TABLE estoque; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.estoque TO vendedor;


--
-- Name: SEQUENCE estoque_estq_cd_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.estoque_estq_cd_id_seq TO vendedor;
GRANT ALL ON SEQUENCE public.estoque_estq_cd_id_seq TO cliente;


--
-- Name: TABLE pedido; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.pedido TO cliente;
GRANT SELECT ON TABLE public.pedido TO vendedor;


--
-- Name: TABLE produto; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.produto TO cliente;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.produto TO vendedor;


--
-- Name: TABLE usuario; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE ON TABLE public.usuario TO cliente;


--
-- Name: SEQUENCE pedido_ped_cd_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.pedido_ped_cd_id_seq TO vendedor;
GRANT ALL ON SEQUENCE public.pedido_ped_cd_id_seq TO cliente;


--
-- Name: SEQUENCE produto_prodt_cd_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.produto_prodt_cd_id_seq TO vendedor;
GRANT ALL ON SEQUENCE public.produto_prodt_cd_id_seq TO cliente;


--
-- Name: SEQUENCE usuario_usu_cd_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.usuario_usu_cd_id_seq TO vendedor;
GRANT ALL ON SEQUENCE public.usuario_usu_cd_id_seq TO cliente;


--
-- PostgreSQL database dump complete
--

